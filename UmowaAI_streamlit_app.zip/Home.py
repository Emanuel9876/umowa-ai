
import streamlit as st

st.set_page_config(page_title="UmowaAI – Strona Główna", layout="wide")
st.title("🏠 UmowaAI – Strona Główna")
st.markdown("Witaj! Skorzystaj z menu po lewej stronie, aby analizować umowę.")
