
import streamlit as st

st.title("📤 Wgraj PDF")
uploaded_file = st.file_uploader("Wgraj plik PDF z umową", type="pdf")
if uploaded_file:
    st.success("Plik został wgrany!")
