
import streamlit as st

st.title("📥 Pobierz raport")
st.download_button("📩 Pobierz jako TXT", data="To jest przykładowy raport.", file_name="raport.txt")
