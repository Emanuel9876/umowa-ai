
import streamlit as st

st.title("📄 Wklej treść umowy")
contract_text = st.text_area("Wklej tutaj treść umowy do analizy:", height=300)
if contract_text:
    st.info("Tu możesz przeprowadzić analizę tekstową (np. z AI).")
